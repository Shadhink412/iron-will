
import { useState, useEffect } from 'react';
import type { TimeDuration } from '../types';

const calculateDuration = (startDate: number): TimeDuration => {
  const now = Date.now();
  let diff = Math.floor((now - startDate) / 1000);

  const days = Math.floor(diff / (24 * 3600));
  diff -= days * 24 * 3600;

  const hours = Math.floor(diff / 3600);
  diff -= hours * 3600;

  const minutes = Math.floor(diff / 60);
  diff -= minutes * 60;

  const seconds = diff;

  return { days, hours, minutes, seconds };
};

export const useTimer = (startDate: number | null): TimeDuration => {
  const [duration, setDuration] = useState<TimeDuration>(
    startDate ? calculateDuration(startDate) : { days: 0, hours: 0, minutes: 0, seconds: 0 }
  );

  useEffect(() => {
    if (!startDate) {
        setDuration({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
    }

    const timerId = setInterval(() => {
      setDuration(calculateDuration(startDate));
    }, 1000);

    return () => clearInterval(timerId);
  }, [startDate]);

  return duration;
};
