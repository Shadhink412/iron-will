
import React, { useState, useEffect } from 'react';
import { Plus, Settings, BrainCircuit, RefreshCw, Trash2, Award, Star, Shield, Pencil } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { useTimer } from '../../hooks/useTimer';
import { getMotivationalQuote } from '../../services/geminiService';
import AddAddictionModal from '../modals/AddAddictionModal';
import AICoachModal from '../modals/AICoachModal';

const TimerDisplay: React.FC<{ duration: { days: number; hours: number; minutes: number; seconds: number } }> = ({ duration }) => {
  const pad = (num: number) => num.toString().padStart(2, '0');
  return (
    <div className="text-center">
      <div className="text-5xl md:text-6xl font-bold tracking-tighter text-gray-800 dark:text-white">
        {duration.days > 0 && `${duration.days}d `}{pad(duration.hours)}:{pad(duration.minutes)}:{pad(duration.seconds)}
      </div>
      <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
        {duration.days > 0 ? 'Days · Hours · Minutes · Seconds' : 'Hours · Minutes · Seconds'}
      </div>
    </div>
  );
};

const HomeScreen: React.FC = () => {
  const { addictions, activeAddiction, setActiveAddictionId, resetAddiction, deleteAddiction, username, updateUsername } = useAppContext();
  const duration = useTimer(activeAddiction?.startDate || null);
  const [quote, setQuote] = useState<string>('Loading an inspiring thought for you...');
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isCoachModalOpen, setCoachModalOpen] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);
  const longestStreak = addictions.length > 0 ? Math.max(...addictions.map(a => (Date.now() - a.startDate))) : 0;


  useEffect(() => {
    getMotivationalQuote().then(setQuote);
  }, []);

  const handleReset = () => {
    if (activeAddiction && window.confirm(`Are you sure you want to reset your streak for "${activeAddiction.name}"? This action cannot be undone.`)) {
      resetAddiction(activeAddiction.id);
    }
  };

  const handleDelete = () => {
    if (activeAddiction && window.confirm(`Are you sure you want to permanently delete "${activeAddiction.name}"? All progress will be lost.`)) {
      deleteAddiction(activeAddiction.id);
      setSettingsOpen(false);
    }
  };
  
  const handleEditUsername = () => {
    const newName = window.prompt("Enter your new username:", username);
    if (newName && newName.trim().length > 0) {
      updateUsername(newName.trim());
    }
  };

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  }

  return (
    <div className="p-4 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{greeting()},</h1>
          <div className="flex items-center gap-2">
             <p className="text-gray-600 dark:text-gray-300">{username}</p>
             <button onClick={handleEditUsername} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white">
                <Pencil size={14}/>
             </button>
          </div>
        </div>
        <button onClick={() => setCoachModalOpen(true)} className="p-2 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors shadow-md">
          <BrainCircuit size={24} />
        </button>
      </header>

      {addictions.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-2">Welcome to Iron Will</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">Start your journey by tracking an addiction or habit you want to control.</p>
          <button onClick={() => setAddModalOpen(true)} className="bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600 transition-transform transform hover:scale-105 shadow-lg">
            <Plus className="inline-block mr-2" size={20}/>
            Add First Goal
          </button>
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
          <div className="flex justify-between items-start mb-4">
            <div>
              <select 
                value={activeAddiction?.id || ''}
                onChange={(e) => setActiveAddictionId(e.target.value)}
                className="text-xl font-bold bg-transparent dark:bg-gray-800 border-none focus:ring-0 p-0"
              >
                {addictions.map(add => (
                  <option key={add.id} value={add.id}>{add.name}</option>
                ))}
              </select>
              <p className="text-sm text-gray-500 dark:text-gray-400">Current Streak</p>
            </div>
            <div className="relative">
              <button onClick={() => setSettingsOpen(!isSettingsOpen)} className="p-2 text-gray-500 hover:text-gray-800 dark:hover:text-white">
                <Settings size={20} />
              </button>
              {isSettingsOpen && (
                 <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 rounded-md shadow-lg z-10 border dark:border-gray-600">
                   <button onClick={() => setAddModalOpen(true)} className="w-full text-left flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                     <Plus size={16} className="mr-2"/> Add New
                   </button>
                   <button onClick={handleDelete} className="w-full text-left flex items-center px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-600">
                    <Trash2 size={16} className="mr-2"/> Delete
                   </button>
                 </div>
              )}
            </div>
          </div>
          <TimerDisplay duration={duration} />
          <div className="mt-6 flex justify-center">
            <button onClick={handleReset} className="bg-red-500 text-white font-semibold py-2 px-5 rounded-full hover:bg-red-600 transition-all shadow-md flex items-center">
              <RefreshCw size={16} className="mr-2"/> Reset Streak
            </button>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-md">
        <h3 className="font-semibold mb-3 text-gray-700 dark:text-gray-200">Achievements</h3>
        <div className="grid grid-cols-3 gap-4 text-center">
            <div className="flex flex-col items-center p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <Award size={24} className="text-yellow-500"/>
                <span className="font-bold text-lg">{duration.days}</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">Current Streak</span>
            </div>
            <div className="flex flex-col items-center p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <Star size={24} className="text-green-500"/>
                <span className="font-bold text-lg">{Math.floor(longestStreak / (1000 * 60 * 60 * 24))}d</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">Longest Streak</span>
            </div>
             <div className="flex flex-col items-center p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <Shield size={24} className="text-blue-500"/>
                <span className="font-bold text-lg">{addictions.length}</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">Goals</span>
            </div>
        </div>
      </div>

      <div className="bg-blue-50 dark:bg-gray-800 border-l-4 border-blue-400 rounded-r-lg p-4 shadow-md">
        <h3 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">Daily Motivation</h3>
        <p className="text-gray-700 dark:text-gray-300 italic">"{quote}"</p>
      </div>

      <AddAddictionModal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} />
      <AICoachModal isOpen={isCoachModalOpen} onClose={() => setCoachModalOpen(false)} />
    </div>
  );
};

export default HomeScreen;