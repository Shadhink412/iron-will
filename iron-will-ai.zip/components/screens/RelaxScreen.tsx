import React, { useState, useEffect, useRef } from 'react';
import { Wind, Play, Pause, RotateCcw } from 'lucide-react';

const BreathingExercise: React.FC = () => {
  const [instruction, setInstruction] = useState('Get Ready...');
  const [isBreathing, setIsBreathing] = useState(false);
  // Fix: Correctly type the ref for a browser environment where setTimeout returns a number.
  const cycleRef = useRef<number | null>(null);

  const startBreathing = () => {
    setIsBreathing(true);
    const breathe = () => {
      setInstruction('Breathe In...');
      // Fix: Use window.setTimeout to ensure the browser's implementation is used, which returns a number.
      cycleRef.current = window.setTimeout(() => {
        setInstruction('Hold...');
        // Fix: Use window.setTimeout to ensure the browser's implementation is used, which returns a number.
        cycleRef.current = window.setTimeout(() => {
          setInstruction('Breathe Out...');
          // Fix: Use window.setTimeout to ensure the browser's implementation is used, which returns a number.
          cycleRef.current = window.setTimeout(breathe, 6000); // 6s out
        }, 3000); // 3s hold
      }, 4000); // 4s in
    };
    breathe();
  };

  const stopBreathing = () => {
    setIsBreathing(false);
    if (cycleRef.current) {
      // Fix: Use window.clearTimeout to match window.setTimeout.
      window.clearTimeout(cycleRef.current);
    }
    setInstruction('Get Ready...');
  };
  
  useEffect(() => {
    return () => {
      // Fix: Use window.clearTimeout to match window.setTimeout.
      if (cycleRef.current) window.clearTimeout(cycleRef.current);
    }
  }, []);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-md">
      <h2 className="font-semibold text-lg mb-4 text-gray-700 dark:text-gray-200">Box Breathing</h2>
      <div className="w-32 h-32 mx-auto bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center transition-transform duration-1000" style={{ transform: isBreathing ? 'scale(1.1)' : 'scale(1)'}}>
        <p className="text-xl font-medium text-blue-600 dark:text-blue-300">{instruction}</p>
      </div>
      <div className="mt-6">
        {isBreathing ? (
          <button onClick={stopBreathing} className="bg-red-500 text-white font-bold py-2 px-6 rounded-full hover:bg-red-600 transition-colors flex items-center gap-2 mx-auto">
            <Pause size={20} /> Stop
          </button>
        ) : (
          <button onClick={startBreathing} className="bg-blue-500 text-white font-bold py-2 px-6 rounded-full hover:bg-blue-600 transition-colors flex items-center gap-2 mx-auto">
            <Play size={20} /> Start
          </button>
        )}
      </div>
    </div>
  );
};


const RelaxScreen: React.FC = () => {
  return (
    <div className="p-4 space-y-6">
      <header className="flex items-center gap-3">
        <Wind size={28} className="text-green-500"/>
        <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Relax & Focus</h1>
            <p className="text-gray-500 dark:text-gray-400">Tools to find your calm and center yourself.</p>
        </div>
      </header>

      <BreathingExercise />

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-md">
         <h2 className="font-semibold text-lg mb-4 text-gray-700 dark:text-gray-200">Calming Sounds</h2>
         <p className="text-gray-500 dark:text-gray-400">Feature coming soon.</p>
      </div>
    </div>
  );
};

export default RelaxScreen;