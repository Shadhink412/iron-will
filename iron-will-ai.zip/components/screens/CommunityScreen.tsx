
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Send, Loader2, Award, Star, Shield } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { useTimer } from '../../hooks/useTimer';
import { listenForMessages, sendMessage } from '../../services/firebaseService';
import type { ChatMessage as ChatMessageType, BadgeTier } from '../../types';
import { firebaseConfig } from '../../firebaseConfig';

const getBadgeForStreak = (days: number): { tier: BadgeTier, icon: React.ReactNode, color: string } => {
    if (days >= 90) return { tier: 'platinum', icon: <Shield size={10} />, color: 'text-purple-400' };
    if (days >= 30) return { tier: 'gold', icon: <Star size={10} />, color: 'text-yellow-400' };
    if (days >= 7) return { tier: 'silver', icon: <Award size={10} />, color: 'text-gray-400' };
    if (days >= 1) return { tier: 'bronze', icon: <Award size={10} />, color: 'text-orange-400' };
    return { tier: 'none', icon: null, color: '' };
};

const UserAvatar: React.FC<{ username: string; streakDays: number }> = ({ username, streakDays }) => {
    const badge = getBadgeForStreak(streakDays);
    return (
        <div className="relative w-10 h-10">
            <div className="w-10 h-10 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center font-bold text-gray-600 dark:text-gray-300">
                {username.charAt(0).toUpperCase()}
            </div>
            {badge.tier !== 'none' && (
                <div className={`absolute -bottom-1 -right-1 flex items-center justify-center w-5 h-5 bg-white dark:bg-gray-700 rounded-full border-2 border-white dark:border-gray-800 ${badge.color}`}>
                   {badge.icon}
                </div>
            )}
        </div>
    );
};


const ChatMessage: React.FC<{ msg: ChatMessageType; isOwnMessage: boolean }> = ({ msg, isOwnMessage }) => {
  const { sender, message, timestamp, streakDays } = msg;

  return (
    <div className={`flex items-start gap-3 ${isOwnMessage ? 'flex-row-reverse' : ''}`}>
      {!isOwnMessage && <UserAvatar username={sender} streakDays={streakDays} />}
      <div className={`flex flex-col ${isOwnMessage ? 'items-end' : 'items-start'}`}>
        <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${isOwnMessage ? 'bg-blue-500 text-white rounded-br-none' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-none'}`}>
          {!isOwnMessage && <p className="text-xs font-bold text-blue-400 mb-1">{sender}</p>}
          <p className="text-sm break-words">{message}</p>
        </div>
        <p className="text-xs text-gray-400 mt-1 px-1">
            {new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};


const CommunityScreen: React.FC = () => {
    const { username, activeAddiction, addictions } = useAppContext();
    const duration = useTimer(activeAddiction?.startDate || null);
    
    const [currentRoom, setCurrentRoom] = useState(activeAddiction ? activeAddiction.name : 'General');
    const [messages, setMessages] = useState<ChatMessageType[]>([]);
    const [inputMessage, setInputMessage] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    
    const isFirebaseConfigured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("YOUR");
    
    const roomOptions = useMemo(() => {
        const rooms = new Set(addictions.map(a => a.name));
        rooms.add('General');
        return Array.from(rooms);
    }, [addictions]);
    
    // Sync room with active addiction from context
    useEffect(() => {
        setCurrentRoom(activeAddiction ? activeAddiction.name : 'General');
    }, [activeAddiction]);

    useEffect(() => {
        if (!isFirebaseConfigured) {
            setIsLoading(false);
            return;
        }

        setIsLoading(true);
        setMessages([]); // Clear messages when room changes
        const unsubscribe = listenForMessages(currentRoom, (newMessages) => {
            setMessages(newMessages);
            setIsLoading(false);
        });

        return () => {
            if (unsubscribe) {
                unsubscribe();
            }
        };
    }, [currentRoom, isFirebaseConfigured]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleSendMessage = () => {
        if (inputMessage.trim() === '' || !isFirebaseConfigured) return;
        
        const messagePayload = {
            sender: username,
            message: inputMessage.trim(),
            goal: activeAddiction?.name || 'General',
            streakDays: duration.days
        };
        sendMessage(currentRoom, messagePayload);
        setInputMessage('');
    };
    
    const renderContent = () => {
        if (!isFirebaseConfigured) {
            return (
                <div className="flex-1 flex items-center justify-center text-center text-gray-500 dark:text-gray-400 p-4">
                    <p>Firebase is not configured. Please add your project credentials to <code className="bg-gray-200 dark:bg-gray-700 p-1 rounded text-xs">firebaseConfig.ts</code> to enable the community chat feature.</p>
                </div>
            );
        }

        if (isLoading) {
            return (
                <div className="flex-1 flex items-center justify-center text-gray-500 dark:text-gray-400">
                    <Loader2 className="animate-spin mr-2" />
                    <span>Loading chat...</span>
                </div>
            );
        }

        if (messages.length === 0) {
            return (
                <div className="flex-1 flex items-center justify-center text-center text-gray-500 dark:text-gray-400">
                    <p>It's quiet in here...<br/>Be the first to send a message of support!</p>
                </div>
            );
        }

        return (
            <div className="flex-1 overflow-y-auto space-y-4 p-4">
                {messages.map((msg) => (
                    <ChatMessage key={msg.id} msg={msg} isOwnMessage={msg.sender === username} />
                ))}
                <div ref={messagesEndRef} />
            </div>
        );
    };

  return (
    <div className="flex flex-col h-full">
      <header className="p-4 mb-0 border-b border-gray-200 dark:border-gray-700">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-1">Community Support</h1>
        <div className="flex items-center gap-2 text-sm">
            <label htmlFor="room-select" className="text-gray-500 dark:text-gray-400">Room:</label>
            <select
                id="room-select"
                value={currentRoom}
                onChange={(e) => setCurrentRoom(e.target.value)}
                className="font-semibold text-blue-500 bg-transparent dark:bg-gray-900 border-none focus:ring-0 p-1 -ml-1 rounded-md"
                aria-label="Select chat room"
            >
                {roomOptions.map(room => (
                    <option key={room} value={room}>{room}</option>
                ))}
            </select>
        </div>
      </header>
      
      {renderContent()}

      <div className="mt-auto p-4 flex items-center gap-2 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <input
          type="text"
          placeholder={isFirebaseConfigured ? "Type your message..." : "Chat disabled"}
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          disabled={!isFirebaseConfigured}
          className="flex-1 w-full px-4 py-2 bg-gray-100 dark:bg-gray-700 border border-transparent rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button 
            onClick={handleSendMessage}
            disabled={!isFirebaseConfigured || inputMessage.trim() === ''}
            className="p-3 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

export default CommunityScreen;
