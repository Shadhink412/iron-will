
import React, { useState } from 'react';
import { Book, Sparkles, Loader2, Save } from 'lucide-react';
import { analyzeJournalEntry } from '../../services/geminiService';

const JournalScreen: React.FC = () => {
  const [entry, setEntry] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAnalyze = async () => {
    if (entry.trim().length === 0) {
      alert("Please write something in your journal before analyzing.");
      return;
    }
    setIsLoading(true);
    setAnalysis('');
    try {
      const result = await analyzeJournalEntry(entry);
      setAnalysis(result);
    } catch (error) {
      setAnalysis("An error occurred during analysis. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-6">
      <header className="flex items-center gap-3">
        <Book size={28} className="text-blue-500"/>
        <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">My Journal</h1>
            <p className="text-gray-500 dark:text-gray-400">Reflect on your day, your thoughts, and your progress.</p>
        </div>
      </header>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-md">
        <textarea
          value={entry}
          onChange={(e) => setEntry(e.target.value)}
          placeholder="How are you feeling today? What challenges did you face? What were your victories?"
          className="w-full h-48 p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
        />
        <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <button
                onClick={() => alert("Journal saved! (Feature mock-up)")}
                className="w-full sm:w-auto flex-1 flex justify-center items-center gap-2 bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-200 font-semibold py-2 px-4 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
            >
                <Save size={18} />
                Save Entry
            </button>
            <button
                onClick={handleAnalyze}
                disabled={isLoading}
                className="w-full sm:w-auto flex-1 flex justify-center items-center gap-2 bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-blue-300 disabled:cursor-not-allowed"
            >
            {isLoading ? (
              <Loader2 size={18} className="animate-spin" />
            ) : (
              <Sparkles size={18} />
            )}
            {isLoading ? 'Analyzing...' : 'Get AI Insights'}
          </button>
        </div>
      </div>
      
      {analysis && (
        <div className="bg-blue-50 dark:bg-gray-800 border-l-4 border-blue-400 rounded-r-lg p-4 shadow-md animate-fade-in">
          <h3 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">AI Analysis</h3>
          <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{analysis}</p>
        </div>
      )}
    </div>
  );
};

export default JournalScreen;
