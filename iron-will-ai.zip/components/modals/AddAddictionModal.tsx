
import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { X } from 'lucide-react';

interface AddAddictionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddAddictionModal: React.FC<AddAddictionModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const { addAddiction } = useAppContext();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      addAddiction(name.trim());
      setName('');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm p-6 relative">
        <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
          <X size={24} />
        </button>
        <h2 className="text-xl font-bold mb-4">Add a New Goal</h2>
        <form onSubmit={handleSubmit}>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">What habit or addiction do you want to track?</p>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Smoking, Social Media"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 dark:bg-gray-700"
            autoFocus
          />
          <button
            type="submit"
            className="w-full mt-6 bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-blue-300"
            disabled={!name.trim()}
          >
            Start Tracking
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddAddictionModal;
