
import React from 'react';
import { Home, MessageCircle, BookOpen, Wind } from 'lucide-react';
import type { View } from '../../types';

interface BottomNavProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

const NavItem: React.FC<{
  icon: React.ElementType;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon: Icon, label, isActive, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center justify-center w-full pt-2 pb-1 transition-colors duration-200 ${
        isActive ? 'text-blue-500' : 'text-gray-400 hover:text-blue-500'
      }`}
    >
      <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
      <span className="text-xs font-medium mt-1">{label}</span>
    </button>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ activeView, setActiveView }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto h-16 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-t-lg">
      <div className="flex justify-around items-center h-full">
        <NavItem
          icon={Home}
          label="Home"
          isActive={activeView === 'home'}
          onClick={() => setActiveView('home')}
        />
        <NavItem
          icon={MessageCircle}
          label="Community"
          isActive={activeView === 'community'}
          onClick={() => setActiveView('community')}
        />
        <NavItem
          icon={BookOpen}
          label="Journal"
          isActive={activeView === 'journal'}
          onClick={() => setActiveView('journal')}
        />
        <NavItem
          icon={Wind}
          label="Relax"
          isActive={activeView === 'relax'}
          onClick={() => setActiveView('relax')}
        />
      </div>
    </div>
  );
};

export default BottomNav;
