// FIX: Using Firebase v9 compat libraries to resolve module import errors.
// This approach is more robust against potential bundler/environment issues
// with the modular SDK's named exports.
import firebase from 'firebase/compat/app';
import 'firebase/compat/database';

import { firebaseConfig } from "../firebaseConfig";
import type { ChatMessage } from "../types";

let db: firebase.database.Database | null = null;

// A simple check to ensure the config isn't using placeholder values.
const isFirebaseConfigured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("YOUR");

if (isFirebaseConfigured) {
  try {
    // Initialize Firebase app using the v9 compat/v8 syntax
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
    db = firebase.database();
  } catch (error) {
    console.error("Firebase initialization error:", error);
    db = null;
  }
} else {
    console.warn("Firebase is not configured. Please add your project credentials to firebaseConfig.ts. Chat features will be disabled.");
}

/**
 * Sanitizes a string to be used as a valid Firebase Realtime Database key.
 * Removes characters that are not allowed: ., $, #, [, ], /, or ASCII control characters.
 * @param name The string to sanitize.
 * @returns A sanitized string.
 */
export const sanitizeRoomName = (name: string): string => {
  // Replace forbidden characters, collapse spaces, and convert to lowercase.
  return name.replace(/[.$#\[\]/]/g, '').replace(/\s+/g, '-').toLowerCase() || 'general';
};

/**
 * Listens for new messages in a specific chat room.
 * @param roomName The name of the chat room.
 * @param callback The function to call with the updated list of messages.
 * @returns An unsubscribe function to stop listening for updates.
 */
export const listenForMessages = (roomName: string, callback: (messages: ChatMessage[]) => void): (() => void) | null => {
  if (!db) return null;

  const sanitizedRoom = sanitizeRoomName(roomName);
  const messagesRef = db.ref(`chats/${sanitizedRoom}`);
  
  const listener = messagesRef.on('value', (snapshot) => {
    if (snapshot.exists()) {
      const messagesData = snapshot.val();
      const messagesList: ChatMessage[] = Object.keys(messagesData).map(key => ({
        id: key,
        ...messagesData[key]
      })).sort((a, b) => a.timestamp - b.timestamp);
      callback(messagesList);
    } else {
      callback([]); // No messages in the room
    }
  });

  // Return a function to unsubscribe from the listener
  return () => messagesRef.off('value', listener);
};

/**
 * Sends a new message to a specific chat room.
 * @param roomName The name of the chat room.
 * @param message The message object containing sender, text, goal, and streak.
 */
export const sendMessage = (roomName: string, message: { sender: string; message: string; goal: string; streakDays: number; }): void => {
  if (!db) {
    console.error("Firebase is not initialized. Cannot send message.");
    return;
  }
  
  const sanitizedRoom = sanitizeRoomName(roomName);
  const messagesRef = db.ref(`chats/${sanitizedRoom}`);
  
  messagesRef.push({
    ...message,
    timestamp: firebase.database.ServerValue.TIMESTAMP
  });
};
