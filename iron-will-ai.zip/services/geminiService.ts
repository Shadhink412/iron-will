
import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available from environment variables
const apiKey = process.env.API_KEY;
if (!apiKey) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey });

export const getMotivationalQuote = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Generate a short, powerful motivational quote for someone overcoming addiction. Be concise and inspiring.",
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error fetching motivational quote:", error);
    return "Your strength is greater than your struggle. Keep going.";
  }
};

export const getAICoachResponse = async (history: { role: 'user' | 'model', parts: {text: string}[] }[], newMessage: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: "You are a compassionate and supportive AI coach named 'Iron Will AI'. Your role is to help users on their journey of addiction recovery. You provide motivation, relapse prevention tips, and daily reflections. Use sentiment analysis to detect when a user feels weak and respond with encouragement. Your tone should be empathetic, non-judgmental, and empowering. Keep responses helpful and relatively brief.",
        },
        history
    });
    const response = await chat.sendMessage({ message: newMessage });
    return response.text.trim();
  } catch (error) {
    console.error("Error getting AI coach response:", error);
    return "I'm having a little trouble connecting right now. Remember to be kind to yourself. You're doing great work.";
  }
};

export const analyzeJournalEntry = async (entry: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following journal entry from a user in addiction recovery. Identify potential mood trends, triggers, and positive signs. Provide personalized, constructive, and encouraging advice based on the entry. Keep the analysis to 2-3 short paragraphs.\n\nJournal Entry:\n"${entry}"`,
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error analyzing journal entry:", error);
    return "Could not analyze the entry at this time. Journaling is a powerful tool for self-reflection. Keep it up!";
  }
};
