
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Addiction } from '../types';

interface AppContextType {
  addictions: Addiction[];
  activeAddiction: Addiction | null;
  setActiveAddictionId: (id: string | null) => void;
  addAddiction: (name: string) => void;
  resetAddiction: (id: string) => void;
  deleteAddiction: (id: string) => void;
  username: string;
  updateUsername: (newName: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const USERNAME_KEY = 'iron-will-username';
const ADDICTIONS_KEY = 'iron-will-addictions';
const ACTIVE_ADDICTION_ID_KEY = 'iron-will-active-addiction-id';

const generateRandomUsername = () => {
    const adjectives = ["Brave", "Calm", "Wise", "Strong", "Hopeful", "Serene", "Kind"];
    const animals = ["Lion", "Eagle", "Dolphin", "Wolf", "Phoenix", "Bear", "Owl"];
    return `${adjectives[Math.floor(Math.random() * adjectives.length)]}${animals[Math.floor(Math.random() * animals.length)]}${Math.floor(Math.random() * 100)}`;
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [addictions, setAddictions] = useState<Addiction[]>([]);
  const [activeAddictionId, setActiveAddictionIdState] = useState<string | null>(null);
  const [username, setUsername] = useState<string>('');
  
  useEffect(() => {
    try {
      // Load username
      let storedUsername = localStorage.getItem(USERNAME_KEY);
      if (!storedUsername) {
        storedUsername = generateRandomUsername();
        localStorage.setItem(USERNAME_KEY, storedUsername);
      }
      setUsername(storedUsername);

      // Load addictions
      const storedAddictions = localStorage.getItem(ADDICTIONS_KEY);
      if (storedAddictions) {
        setAddictions(JSON.parse(storedAddictions));
      }

      // Load active addiction ID
      const storedActiveId = localStorage.getItem(ACTIVE_ADDICTION_ID_KEY);
      if (storedActiveId) {
        setActiveAddictionIdState(storedActiveId);
      } else if (storedAddictions) {
        const parsedAddictions = JSON.parse(storedAddictions);
        if (parsedAddictions.length > 0) {
            setActiveAddictionIdState(parsedAddictions[0].id);
        }
      }

    } catch (error) {
      console.error("Failed to load data from localStorage", error);
    }
  }, []);

  const saveAddictions = useCallback((newAddictions: Addiction[]) => {
    setAddictions(newAddictions);
    localStorage.setItem(ADDICTIONS_KEY, JSON.stringify(newAddictions));
  }, []);
  
  const updateUsername = (newName: string) => {
    setUsername(newName);
    localStorage.setItem(USERNAME_KEY, newName);
  }

  const setActiveAddictionId = (id: string | null) => {
    setActiveAddictionIdState(id);
    if(id) {
        localStorage.setItem(ACTIVE_ADDICTION_ID_KEY, id);
    } else {
        localStorage.removeItem(ACTIVE_ADDICTION_ID_KEY);
    }
  };

  const addAddiction = (name: string) => {
    const newAddiction: Addiction = {
      id: Date.now().toString(),
      name,
      startDate: Date.now(),
    };
    const updatedAddictions = [...addictions, newAddiction];
    saveAddictions(updatedAddictions);
    if (!activeAddictionId) {
      setActiveAddictionId(newAddiction.id);
    }
  };

  const resetAddiction = (id: string) => {
    const updatedAddictions = addictions.map((addiction) =>
      addiction.id === id ? { ...addiction, startDate: Date.now() } : addiction
    );
    saveAddictions(updatedAddictions);
  };

  const deleteAddiction = (id: string) => {
    const updatedAddictions = addictions.filter((addiction) => addiction.id !== id);
    saveAddictions(updatedAddictions);
    if (activeAddictionId === id) {
        const newActiveId = updatedAddictions.length > 0 ? updatedAddictions[0].id : null;
        setActiveAddictionId(newActiveId);
    }
  };
  
  const activeAddiction = addictions.find(a => a.id === activeAddictionId) || null;

  const value = {
    addictions,
    activeAddiction,
    setActiveAddictionId,
    addAddiction,
    resetAddiction,
    deleteAddiction,
    username,
    updateUsername
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};